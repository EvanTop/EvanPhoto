<?php
if (!defined('ABSPATH')) { exit; }
get_header();
?>
<main style="display:flex;align-items:center;justify-content:center;min-height:60vh;color:rgba(255,255,255,.6);font-size:1.25rem;">
  <p>404 &mdash; Page not found.</p>
</main>
<?php get_footer(); ?>
