/* EvanPhoto admin.js — v2.0.0 */
(function ($) {
  function togglePanels(source) {
    $('[data-source-panel="attachment"]').toggle(source === 'attachment');
    $('[data-source-panel="external"]').toggle(source === 'external');
  }

  $(document).on('change', 'input[name="evanphoto_source"]', function () {
    togglePanels($(this).val());
  });

  $(function () {
    togglePanels($('input[name="evanphoto_source"]:checked').val() || 'attachment');

    var frame;
    $('#evanphoto_pick_media').on('click', function (e) {
      e.preventDefault();
      if (frame) { frame.open(); return; }

      frame = wp.media({
        title:    '选择/上传图片',
        button:   { text: '使用该图片' },
        multiple: false
      });

      frame.on('select', function () {
        var attachment = frame.state().get('selection').first().toJSON();
        $('#evanphoto_attachment_id').val(attachment.id);
        $('#evanphoto_media_preview').show().html('<img src="' + attachment.url + '" alt="" />');
        $('input[name="evanphoto_source"][value="attachment"]').prop('checked', true).trigger('change');
      });

      frame.open();
    });

    $('#evanphoto_clear_media').on('click', function (e) {
      e.preventDefault();
      $('#evanphoto_attachment_id').val('');
      $('#evanphoto_media_preview').hide().empty();
    });

    $(document).on('input', 'input[name="evanphoto_external_url"]', function () {
      var url = $(this).val();
      if (url) {
        $('#evanphoto_external_preview').show().html('<img src="' + url + '" alt="" />');
      } else {
        $('#evanphoto_external_preview').hide().empty();
      }
    });
  });
}(jQuery));
