/* EvanPhoto gallery.js — v2.1.0 */
(function () {
  'use strict';
  if (typeof EVANPHOTO === 'undefined') return;

  var DATA         = EVANPHOTO;
  var images       = Array.isArray(DATA.images) ? DATA.images : [];
  var root         = document.getElementById('nextjsconf-modal-root');
  var shareOverlay = document.getElementById('evanphoto-share-overlay');
  var WINDOW_SIZE  = parseInt(DATA.paginationWindow, 10) || 9;
  var ALBUMS_ON    = !!DATA.albumsEnabled;
  var SHARE_BRAND  = DATA.shareBrand  || 'Time.Photo';
  var SHARE_QR_URI = DATA.qrDataUri   || '';   // pre-generated PNG data URI

  var idToIndex = new Map(images.map(function (img, idx) { return [String(img.id), idx]; }));
  var currentIndex    = null;
  var lastNonModalUrl = null;

  // ─── tiny helpers ───────────────────────
  function escAttr(s) { return String(s).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/'/g,'&#39;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
  function escHtml(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
  function setRootVisible(v) { if (!root) return; root.classList.toggle('hidden',!v); if (!v) root.innerHTML=''; }
  function clampIndex(i) { return Math.max(0, Math.min(images.length-1, i)); }

  // ─── Thumb strip ────────────────────────
  function renderThumbStrip(activeIndex) {
    var total=images.length, half=Math.floor(WINDOW_SIZE/2);
    var start=activeIndex-half, end=activeIndex+half;
    if (start<0)       { end+=-start; start=0; }
    if (end>total-1)   { start-=(end-(total-1)); end=total-1; }
    if (start<0) start=0;
    var items=[];
    for (var i=start;i<=end;i++) {
      var img=images[i]; if (!img) continue;
      var a=(i===activeIndex);
      items.push(
        '<button class="'+(a?'z-20 rounded-md shadow shadow-black/50':'z-10')+' relative inline-block w-full shrink-0 transform-gpu overflow-hidden focus:outline-none"'+
        ' data-thumb-index="'+i+'"'+
        ' style="transform:'+(a?'scale(1.25)':'scale(1)')+' translateZ(0);">'+
        '<img class="'+(a?'brightness-110':'brightness-50 hover:brightness-75')+' h-full transform object-cover transition"'+
        ' loading="lazy" decoding="async" src="'+escAttr(img.thumb_url)+'" width="180" height="120" alt="" /></button>'
      );
    }
    return '<div class="fixed inset-x-0 bottom-0 z-40 overflow-hidden bg-gradient-to-b from-black/0 to-black/60">'+
           '<div class="mx-auto mt-6 mb-6 flex aspect-[3/2] h-14 justify-center">'+items.join('')+'</div></div>';
  }

  // ─── EXIF panel ─────────────────────────
  function renderExifPanel(img) {
    var exif=img.exif;
    if (!exif||!Object.keys(exif).length) return '';
    var parts=Object.keys(exif).map(function(k){ return '<span class="evanphoto-exif-item"><strong>'+escHtml(k)+':</strong> '+escHtml(exif[k])+'</span>'; });
    return '<div class="evanphoto-exif-bar">'+parts.join('')+'</div>';
  }

  // ─── Modal HTML ─────────────────────────
  function modalHtml(img, index) {
    var display    = img.display_url||img.full_url||img.thumb_url;
    var isPortrait = !!img.is_portrait;
    var shareUrl   = (DATA.photoPathPrefix||'/p/').replace(/\/+$/,'/')+img.id;

    var containerClass = isPortrait
      ? 'relative z-50 flex w-full max-w-3xl items-center justify-center'
      : 'relative z-50 flex aspect-[3/2] w-full max-w-7xl items-center wide:h-full xl:taller-than-854:h-auto';
    var imgStyle = isPortrait
      ? 'style="max-height:88vh;width:auto;max-width:100%;object-fit:contain;"'
      : 'style="color:transparent;width:100%;height:100%;object-fit:contain;"';

    var shareAttrs=[
      'data-share-type="photo"',
      'data-thumb="'+escAttr(img.thumb_url)+'"',
      'data-brand="'+escAttr(SHARE_BRAND)+'"',
      'data-title="'+escAttr(img.post_title||'')+'"',
    ].join(' ');

    return '<div class="fixed inset-0 z-10 flex items-center justify-center" role="dialog" aria-modal="true">'+
      '<div class="fixed inset-0 z-30 bg-black/70 backdrop-blur-2xl" data-modal-overlay="1"></div>'+
      '<div class="'+containerClass+'">'+
        '<div class="w-full overflow-hidden">'+
          '<div class="relative '+(isPortrait?'':'flex aspect-[3/2] items-center justify-center')+'">'+
            '<div class="'+(isPortrait?'flex justify-center':'absolute')+'" style="opacity:1;transform:none;">'+
              '<img src="'+escAttr(display)+'" decoding="async" '+imgStyle+' alt="'+escAttr(img.post_title||'')+'" />'+
            '</div>'+
          '</div>'+
        '</div>'+
        '<div class="absolute inset-0 mx-auto flex max-w-7xl items-center justify-center">'+
          '<div class="relative '+(isPortrait?'w-full h-full':'aspect-[3/2] max-h-full w-full')+'">'+
            /* nav */
            '<button data-nav="next" class="absolute right-3 top-[calc(50%-16px)] rounded-full bg-black/50 p-3 text-white/75 backdrop-blur-lg transition hover:bg-black/75 hover:text-white focus:outline-none" aria-label="Next">'+
              '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-6 w-6"><path stroke-linecap="round" stroke-linejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5"/></svg>'+
            '</button>'+
            '<button data-nav="prev" class="absolute left-3 top-[calc(50%-16px)] rounded-full bg-black/50 p-3 text-white/75 backdrop-blur-lg transition hover:bg-black/75 hover:text-white focus:outline-none" aria-label="Prev">'+
              '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-6 w-6"><path stroke-linecap="round" stroke-linejoin="round" d="M15.75 19.5L8.25 12l7.5-7.5"/></svg>'+
            '</button>'+
            /* top-right: copy · share · download */
            '<div class="absolute top-0 right-0 flex items-center gap-2 p-3">'+
              '<button data-action="copy-link" class="rounded-full bg-black/50 p-2 text-white/75 backdrop-blur-lg transition hover:bg-black/75 hover:text-white" title="复制链接" data-share-url="'+escAttr(shareUrl)+'">'+
                '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-5 w-5"><path stroke-linecap="round" stroke-linejoin="round" d="M13.19 8.688a4.5 4.5 0 011.242 7.244l-4.5 4.5a4.5 4.5 0 01-6.364-6.364l1.757-1.757m13.35-.622l1.757-1.757a4.5 4.5 0 00-6.364-6.364l-4.5 4.5a4.5 4.5 0 001.242 7.244"/></svg>'+
              '</button>'+
              /* share-card — same share icon */
              '<button data-action="share-card" class="evanphoto-share-trigger rounded-full bg-black/50 p-2 text-white/75 backdrop-blur-lg transition hover:bg-black/75 hover:text-white" title="分享图片" '+shareAttrs+'>'+
                '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-5 w-5"><path stroke-linecap="round" stroke-linejoin="round" d="M7.217 10.907a2.25 2.25 0 100 2.186m0-2.186c.18.324.283.696.283 1.093s-.103.77-.283 1.093m0-2.186l9.566-5.314m-9.566 7.5l9.566 5.314m0 0a2.25 2.25 0 103.935 2.186 2.25 2.25 0 00-3.935-2.186zm0-12.814a2.25 2.25 0 103.933-2.185 2.25 2.25 0 00-3.933 2.185z"/></svg>'+
              '</button>'+
              '<button data-action="download" class="rounded-full bg-black/50 p-2 text-white/75 backdrop-blur-lg transition hover:bg-black/75 hover:text-white" title="下载原图">'+
                '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-5 w-5"><path stroke-linecap="round" stroke-linejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M16.5 12L12 16.5m0 0L7.5 12m4.5 4.5V3"/></svg>'+
              '</button>'+
            '</div>'+
            /* top-left: close */
            '<div class="absolute top-0 left-0 flex items-center gap-2 p-3">'+
              '<button data-action="close" class="rounded-full bg-black/50 p-2 text-white/75 backdrop-blur-lg transition hover:bg-black/75 hover:text-white" aria-label="关闭">'+
                '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="h-5 w-5"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>'+
              '</button>'+
            '</div>'+
          '</div>'+
        '</div>'+
      '</div>'+
      renderExifPanel(img)+
      renderThumbStrip(index)+
    '</div>';
  }

  // ─── Modal lifecycle ─────────────────────
  function openModalByIndex(index, opts) {
    if (!root||!images.length) return;
    index=clampIndex(Number(index));
    var img=images[index]; if (!img) return;
    if (!opts||!opts.skipRememberUrl) lastNonModalUrl=window.location.href;
    currentIndex=index;
    setRootVisible(true);
    root.innerHTML=modalHtml(img,index);
    var newUrl=(DATA.photoPathPrefix||'/p/').replace(/\/+$/,'/')+img.id;
    if (!opts||!opts.skipPushState) window.history.pushState({photo:img.id},'',newUrl);
    bindModalEvents();
  }
  function openModalById(id,opts) { var idx=idToIndex.get(String(id)); if (typeof idx==='number') openModalByIndex(idx,opts); }
  function closeModal(opts) {
    setRootVisible(false); currentIndex=null;
    if (!opts||!opts.skipPushState) window.history.pushState({},'',lastNonModalUrl||DATA.baseUrl||'/');
  }
  function goto(delta) { if (currentIndex===null) return; openModalByIndex(clampIndex(currentIndex+delta),{skipRememberUrl:true}); }
  function downloadCurrent() {
    if (currentIndex===null) return; var img=images[currentIndex]; if (!img) return;
    var a=document.createElement('a'); a.href=img.full_url||img.display_url||img.thumb_url; a.download='photo-'+img.id;
    document.body.appendChild(a); a.click(); a.remove();
  }
  function copyLink(url) {
    var full=window.location.origin+url;
    if (navigator.clipboard&&navigator.clipboard.writeText) navigator.clipboard.writeText(full).then(function(){ showToast('链接已复制'); }).catch(function(){ fbCopy(full); });
    else fbCopy(full);
  }
  function fbCopy(text) {
    var ta=document.createElement('textarea'); ta.value=text; ta.style.cssText='position:fixed;opacity:0;';
    document.body.appendChild(ta); ta.focus(); ta.select();
    try { document.execCommand('copy'); showToast('链接已复制'); } catch(e){ showToast('复制失败'); }
    document.body.removeChild(ta);
  }
  function showToast(msg) {
    var t=document.getElementById('evanphoto-toast');
    if (!t){ t=document.createElement('div'); t.id='evanphoto-toast';
      t.style.cssText='position:fixed;bottom:88px;left:50%;transform:translateX(-50%);background:rgba(0,0,0,.82);color:#fff;padding:8px 20px;border-radius:20px;font-size:13px;z-index:9999;pointer-events:none;transition:opacity .25s;white-space:nowrap;';
      document.body.appendChild(t); }
    t.textContent=msg; t.style.opacity='1';
    clearTimeout(t._timer); t._timer=setTimeout(function(){ t.style.opacity='0'; },2000);
  }

  // ─── Touch swipe ────────────────────────
  var tsX=null,tsY=null;
  function bindSwipe(el) {
    el.addEventListener('touchstart',function(e){ if(e.touches.length!==1) return; tsX=e.touches[0].clientX; tsY=e.touches[0].clientY; },{passive:true});
    el.addEventListener('touchend',function(e){ if(tsX===null) return; var dx=e.changedTouches[0].clientX-tsX,dy=e.changedTouches[0].clientY-tsY; tsX=tsY=null; if(Math.abs(dx)<40||Math.abs(dy)>Math.abs(dx)*0.8) return; goto(dx<0?1:-1); },{passive:true});
  }

  // ─── Modal event binding ─────────────────
  function bindModalEvents() {
    var ov=root.querySelector('[data-modal-overlay="1"]');
    if (ov) ov.addEventListener('click',function(){ closeModal(); });
    root.querySelectorAll('[data-action="close"]').forEach(function(b){ b.addEventListener('click',closeModal); });
    root.querySelectorAll('[data-action="download"]').forEach(function(b){ b.addEventListener('click',downloadCurrent); });
    root.querySelectorAll('[data-action="copy-link"]').forEach(function(b){ b.addEventListener('click',function(){ var u=b.getAttribute('data-share-url'); if(u) copyLink(u); }); });
    var pv=root.querySelector('[data-nav="prev"]'), nx=root.querySelector('[data-nav="next"]');
    if (pv) pv.addEventListener('click',function(){ goto(-1); });
    if (nx) nx.addEventListener('click',function(){ goto(1); });
    root.querySelectorAll('[data-thumb-index]').forEach(function(b){ b.addEventListener('click',function(){ openModalByIndex(Number(b.getAttribute('data-thumb-index')),{skipRememberUrl:true}); }); });
    bindSwipe(root);
    root.querySelectorAll('.evanphoto-share-trigger').forEach(function(b){ b.addEventListener('click',function(e){ e.stopPropagation(); openShareCard(b); }); });
  }

  // ═══════════════════════════════════════════
  // SHARE CARD
  // ═══════════════════════════════════════════
  //
  // Card layout (400 × 500 px  @2× device pixel ratio):
  //
  //  ┌─────────────────────────────────────────┐
  //  │  Photo / hero thumb  (3:2, cover crop)  │  ← top section, 240px tall
  //  │  subtle bottom-vignette                 │
  //  ├─────────────────────────────────────────┤
  //  │  [Photo title if any]    16px, white60  │  ← title zone (below photo)
  //  │                                         │
  //  │  ─────────── divider ───────────        │
  //  │                                         │
  //  │  Time.Photo             [QR 72×72]      │  ← brand bottom-left, QR bottom-right
  //  └─────────────────────────────────────────┘

  function openShareCard(triggerEl) {
    var thumbUrl = triggerEl.getAttribute('data-thumb')  || '';
    var brand    = triggerEl.getAttribute('data-brand')  || SHARE_BRAND;
    var title    = triggerEl.getAttribute('data-title')  || '';
    if (!shareOverlay) return;
    shareOverlay.classList.remove('hidden');
    shareOverlay.innerHTML = buildShareOverlayHtml();
    var canvas   = shareOverlay.querySelector('#evanphoto-share-canvas');
    var saveBtn  = shareOverlay.querySelector('[data-share-save]');
    var closeBtn = shareOverlay.querySelector('[data-share-close]');
    var backdrop = shareOverlay.querySelector('[data-share-backdrop]');
    if (closeBtn)  closeBtn.addEventListener('click',  closeShareCard);
    if (backdrop)  backdrop.addEventListener('click',  closeShareCard);
    if (saveBtn)   saveBtn.addEventListener('click',   function(){ saveShareCanvas(canvas); });
    renderShareCanvas(canvas, { thumbUrl:thumbUrl, brand:brand, title:title });
  }

  function closeShareCard() {
    if (!shareOverlay) return;
    shareOverlay.classList.add('hidden');
    shareOverlay.innerHTML='';
  }

  function buildShareOverlayHtml() {
    return [
      /* Backdrop */
      '<div data-share-backdrop style="position:absolute;inset:0;background:rgba(235,235,240,0.92);backdrop-filter:blur(4px);-webkit-backdrop-filter:blur(4px);"></div>',
      /* Scroll container — safe on all screen sizes */
      '<div style="',
        'position:relative;z-index:1;',
        'display:flex;flex-direction:column;align-items:center;justify-content:center;gap:16px;',
        'padding:env(safe-area-inset-top,24px) 16px env(safe-area-inset-bottom,24px);',
        'min-height:100vh;',
        'box-sizing:border-box;',
        'overflow-y:auto;-webkit-overflow-scrolling:touch;',
      '">',
        /* Canvas wrapper — fills available width on mobile, capped at 420px on desktop */
        '<div style="position:relative;width:min(420px,calc(100vw - 32px));">',
          /* canvas fills wrapper width; renderShareCanvas reads clientWidth to size itself */
          '<canvas id="evanphoto-share-canvas" style="',
            'display:block;width:100%;height:auto;',
            'border-radius:10px;',
          '"></canvas>',
          /* Invisible hit-area button over the × drawn on the canvas top-right */
          '<button data-share-close style="',
            'position:absolute;top:0;right:0;',
            'width:44px;height:44px;',
            'background:transparent;border:none;cursor:pointer;',
            'border-radius:0 10px 0 0;',
          '"></button>',
        '</div>',
        /* Save button */
        '<button data-share-save style="',
          'display:inline-block;',
          'padding:10px 36px;border-radius:6px;',
          'background:#ffffff;color:#111111;',
          'font-size:15px;font-weight:400;letter-spacing:.01em;',
          'border:1.5px solid #888;cursor:pointer;',
          'box-shadow:0 1px 4px rgba(0,0,0,.08);',
          '-webkit-tap-highlight-color:transparent;',
        '">保存图片</button>',
        /* Mobile hint */
        '<p style="font-size:11px;color:rgba(0,0,0,.35);margin:0;text-align:center;">移动端可长按图片直接保存</p>',
      '</div>',
    ].join('');
  }

  function saveShareCanvas(canvas) {
    try {
      var link=document.createElement('a');
      link.download='timephoto-share.png';
      link.href=canvas.toDataURL('image/png');
      document.body.appendChild(link); link.click(); link.remove();
    } catch(e){ showToast('请长按图片保存'); }
  }

  // ─── Canvas renderer ────────────────────
  // Reference design:
  //  • White card, 10px radius, subtle shadow
  //  • Top bar: #1a1a1a, 44px — green dot + brand name (white) + × icon
  //  • Photo: 14px padding each side, 3:2 ratio, 8px radius
  //  • Bottom strip: 52px white — title left (green), domain right (green), 15px font
  function renderShareCanvas(canvas, opts) {
    var DPR = Math.min(window.devicePixelRatio||1, 2);
    // Use the wrapper's rendered CSS width so the canvas fills it on every screen size
    var cssW  = canvas.parentElement ? canvas.parentElement.clientWidth : 420;
    if (cssW < 10) cssW = 420;                      // safety fallback
    var W      = cssW;
    var TOPBAR = 44, PAD = 14, BOTTOM = 52;
    var photoH = Math.round((W - PAD*2) * 2/3);   // 3:2 ratio
    var H = TOPBAR + PAD + photoH + PAD + BOTTOM;  // equal PAD on all four sides of photo

    canvas.width  = Math.round(W*DPR);
    canvas.height = Math.round(H*DPR);
    canvas.style.width  = W+'px';
    canvas.style.height = H+'px';
    var ctx = canvas.getContext('2d');
    ctx.scale(DPR, DPR);

    var GREEN  = '#3a7d44';
    var CARD_R = 10;

    // ── White card background ──
    ctx.fillStyle = '#ffffff';
    rr(ctx, 0, 0, W, H, CARD_R);
    ctx.fill();

    // ── Card border (drawn inside canvas so it appears in saved PNG) ──
    ctx.strokeStyle = 'rgba(0,0,0,0.12)';
    ctx.lineWidth = 1;
    rr(ctx, 0.5, 0.5, W-1, H-1, CARD_R);
    ctx.stroke();

    // ── Top bar (dark, rounded top corners only) ──
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(CARD_R, 0); ctx.lineTo(W-CARD_R, 0);
    ctx.quadraticCurveTo(W, 0, W, CARD_R);
    ctx.lineTo(W, TOPBAR); ctx.lineTo(0, TOPBAR);
    ctx.lineTo(0, CARD_R); ctx.quadraticCurveTo(0, 0, CARD_R, 0);
    ctx.closePath();
    ctx.fillStyle = '#1a1a1a';
    ctx.fill();
    ctx.restore();

    // Green dot
    ctx.beginPath();
    ctx.arc(20, TOPBAR/2, 5, 0, Math.PI*2);
    ctx.fillStyle = GREEN;
    ctx.fill();

    // Brand name
    ctx.font = '500 15px -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif';
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'middle';
    ctx.fillText(opts.brand || SHARE_BRAND, 34, TOPBAR/2);

    // × close icon (circle outline + cross)
    var cX = W - 20, cY = TOPBAR/2, cR = 11;
    ctx.strokeStyle = 'rgba(255,255,255,0.55)';
    ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.arc(cX, cY, cR, 0, Math.PI*2); ctx.stroke();
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(cX-4, cY-4); ctx.lineTo(cX+4, cY+4);
    ctx.moveTo(cX+4, cY-4); ctx.lineTo(cX-4, cY+4);
    ctx.stroke();

    // ── Photo zone ──
    var pX = PAD, pY = TOPBAR + PAD;
    var pW = W - PAD*2, pH = photoH;

    // ── Bottom strip ──
    function drawBottom() {
      var by = TOPBAR + PAD + pH + PAD;   // PAD below photo = same as other sides

      // Hairline separator — respects horizontal padding
      ctx.strokeStyle = '#e0e0e0';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(PAD, by + 0.5); ctx.lineTo(W - PAD, by + 0.5);
      ctx.stroke();

      var midY = by + BOTTOM / 2;
      ctx.textBaseline = 'middle';

      // Title — left, green, 15px
      if (opts.title) {
        ctx.font = '500 15px -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif';
        ctx.fillStyle = GREEN;
        ctx.textAlign = 'left';
        var t = opts.title.length > 20 ? opts.title.slice(0,19)+'…' : opts.title;
        ctx.fillText(t, PAD + 4, midY);
      }

      // Domain — right, green, 15px (strip https://)
      ctx.font = '500 15px -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif';
      ctx.fillStyle = GREEN;
      ctx.textAlign = 'right';
      var urlText = (DATA.shareQrUrl||'www.time.photo').replace(/^https?:\/\//,'');
      ctx.fillText(urlText, W - PAD - 4, midY);
    }

    if (opts.thumbUrl) {
      var img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = function() {
        ctx.save();
        rr(ctx, pX, pY, pW, pH, 8);
        ctx.clip();
        var sr = img.naturalWidth/img.naturalHeight, dr = pW/pH;
        var sx,sy,sw,sh;
        if (sr > dr) { sh=img.naturalHeight; sw=sh*dr; sx=(img.naturalWidth-sw)/2; sy=0; }
        else         { sw=img.naturalWidth;  sh=sw/dr; sy=(img.naturalHeight-sh)/2; sx=0; }
        ctx.drawImage(img, sx,sy,sw,sh, pX,pY,pW,pH);
        ctx.restore();
        // Subtle photo border
        ctx.strokeStyle='rgba(0,0,0,0.07)'; ctx.lineWidth=1;
        rr(ctx,pX+.5,pY+.5,pW-1,pH-1,8); ctx.stroke();
        drawBottom();
      };
      img.onerror = function() {
        ctx.fillStyle='#f2f2f2';
        rr(ctx,pX,pY,pW,pH,8); ctx.fill();
        drawBottom();
      };
      img.src = opts.thumbUrl;
    } else {
      ctx.fillStyle='#f2f2f2';
      rr(ctx,pX,pY,pW,pH,8); ctx.fill();
      drawBottom();
    }
  }

  // ─── roundRect shorthand ─────────────────
  function rr(ctx,x,y,w,h,r) {
    ctx.beginPath();
    ctx.moveTo(x+r,y); ctx.lineTo(x+w-r,y); ctx.quadraticCurveTo(x+w,y,x+w,y+r);
    ctx.lineTo(x+w,y+h-r); ctx.quadraticCurveTo(x+w,y+h,x+w-r,y+h);
    ctx.lineTo(x+r,y+h); ctx.quadraticCurveTo(x,y+h,x,y+h-r);
    ctx.lineTo(x,y+r); ctx.quadraticCurveTo(x,y,x+r,y);
    ctx.closePath();
  }

  // ─── Draw pre-embedded QR PNG ────────────
  function drawQR(ctx, x, y, size) {
    if (!SHARE_QR_URI) return;
    var qImg=new Image();
    qImg.onload=function(){
      // Subtle bg plate
      ctx.save();
      ctx.fillStyle='rgba(255,255,255,0.05)';
      rr(ctx, x-6, y-6, size+12, size+12, 8); ctx.fill();
      ctx.drawImage(qImg, x, y, size, size);
      ctx.restore();
    };
    qImg.src=SHARE_QR_URI;
  }

  // ─── Wire grid ──────────────────────────
  function wireGrid() {
    document.querySelectorAll('a[data-photo-id]').forEach(function(a){
      a.addEventListener('click',function(e){
        if (e.metaKey||e.ctrlKey||e.shiftKey||e.altKey) return;
        e.preventDefault(); openModalById(a.getAttribute('data-photo-id'));
      });
    });
  }

  function wireShareTriggers() {
    document.querySelectorAll('.evanphoto-share-trigger').forEach(function(btn){
      btn.addEventListener('click',function(e){ e.preventDefault(); e.stopPropagation(); openShareCard(btn); });
    });
  }

  // ─── Keyboard ───────────────────────────
  window.addEventListener('keydown',function(e){
    if (shareOverlay&&!shareOverlay.classList.contains('hidden')){ if(e.key==='Escape') closeShareCard(); return; }
    if (currentIndex===null) return;
    if (e.key==='Escape')     closeModal();
    if (e.key==='ArrowLeft')  goto(-1);
    if (e.key==='ArrowRight') goto(1);
  });

  // ─── Browser back/forward ───────────────
  window.addEventListener('popstate',function(){
    var m=window.location.pathname.match(/\/p\/(\d+)\/?$/);
    if (m){ openModalById(m[1],{skipPushState:true,skipRememberUrl:true}); return; }
    if (currentIndex!==null) closeModal({skipPushState:true});
  });

  // ─── Album filter bar ───────────────────
  function initAlbumBar() {
    if (!ALBUMS_ON) return;
    var bar=document.getElementById('evanphoto-album-bar');
    if (!bar) return;
    var albumMap={};
    document.querySelectorAll('a[data-album-id]').forEach(function(a){
      var aid=a.getAttribute('data-album-id');
      if(aid&&aid!=='0'){ var idx=idToIndex.get(a.getAttribute('data-photo-id')); if(typeof idx==='number') albumMap[aid]=images[idx].album_name||('相册 '+aid); }
    });
    var albumIds=Object.keys(albumMap);
    if (!albumIds.length) return;
    bar.style.display='';
    var allBtn=document.createElement('button'); allBtn.textContent='全部'; allBtn.classList.add('is-active'); allBtn.setAttribute('data-album-filter','0'); bar.appendChild(allBtn);
    albumIds.forEach(function(aid){ var b=document.createElement('button'); b.textContent=albumMap[aid]; b.setAttribute('data-album-filter',aid); bar.appendChild(b); });
    bar.addEventListener('click',function(e){ var b=e.target.closest('[data-album-filter]'); if(!b) return; bar.querySelectorAll('button').forEach(function(x){ x.classList.remove('is-active'); }); b.classList.add('is-active'); filterGrid(b.getAttribute('data-album-filter')); });
  }
  function filterGrid(id){ document.querySelectorAll('a[data-photo-id]').forEach(function(a){ a.style.display=(id==='0'||((a.getAttribute('data-album-id')||'0')===id))?'':'none'; }); }

  // ─── Hero card height alignment ─────────
  (function(){
    try{
      var mq=window.matchMedia&&window.matchMedia('(min-width:1280px)');
      var main=document.getElementById('evanphoto-main'), grid=document.getElementById('evanphoto-grid');
      if(!main||!grid) return;
      var hero=grid.querySelector('.evanphoto-hero'); if(!hero) return;
      var raf=null;
      function align(){
        if(raf) cancelAnimationFrame(raf);
        raf=requestAnimationFrame(function(){
          try{
            if(!mq||!mq.matches){ main.classList.remove('evanphoto-fewrow'); hero.style.height=''; return; }
            var items=Array.from(grid.children||[]);
            var tops=new Set(items.map(function(el){ return el.offsetTop; }));
            if(tops.size!==1){ main.classList.remove('evanphoto-fewrow'); hero.style.height=''; return; }
            main.classList.add('evanphoto-fewrow');
            var sample=items.find(function(el){ return el!==hero; }); if(!sample) return;
            var h=sample.getBoundingClientRect().height;
            if(h>0) hero.style.height=Math.round(h)+'px';
          }catch(e){}
        });
      }
      align(); window.addEventListener('resize',align); window.addEventListener('load',align);
      if(mq&&mq.addEventListener) mq.addEventListener('change',align);
      else if(mq&&mq.addListener) mq.addListener(align);
    }catch(e){}
  })();

  // ─── Inject runtime CSS ──────────────────
  (function(){
    var s=document.createElement('style');
    s.textContent=[
      /* EXIF bar */
      '.evanphoto-exif-bar{position:fixed;bottom:72px;left:50%;transform:translateX(-50%);z-index:45;display:flex;gap:12px;flex-wrap:wrap;justify-content:center;background:rgba(0,0,0,.55);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);border-radius:10px;padding:6px 14px;font-size:12px;color:rgba(255,255,255,.75);pointer-events:none;max-width:90vw;}',
      '.evanphoto-exif-item strong{color:rgba(255,255,255,.5);font-weight:500;margin-right:3px;}',
      /* Share overlay */
      '#evanphoto-share-overlay{position:fixed;inset:0;z-index:200;display:flex;align-items:center;justify-content:center;}',
      '#evanphoto-share-overlay.hidden{display:none;}',
      /* Inside modal the share trigger is icon-only */
      '#nextjsconf-modal-root .evanphoto-share-trigger{background:rgba(0,0,0,.5);border:none;border-radius:9999px;padding:8px;color:rgba(255,255,255,.75);cursor:pointer;}',
      '#nextjsconf-modal-root .evanphoto-share-trigger:hover{background:rgba(0,0,0,.75);color:#fff;}',
      /* Hover states for save/close inside overlay */
      '[data-share-save]:hover{background:rgba(255,255,255,1)!important;transform:translateY(-1px);}',
      '[data-share-close]:hover{background:rgba(255,255,255,.14)!important;color:rgba(255,255,255,1)!important;}',
    ].join('');
    document.head.appendChild(s);
  })();

  // ─── Init ───────────────────────────────
  wireGrid();
  wireShareTriggers();
  initAlbumBar();

  if (typeof window.EVANPHOTO_INITIAL_PHOTO_ID==='number') {
    openModalById(window.EVANPHOTO_INITIAL_PHOTO_ID,{skipRememberUrl:true,skipPushState:true});
  } else {
    var m=window.location.pathname.match(/\/p\/(\d+)\/?$/);
    if (m) openModalById(m[1],{skipRememberUrl:true,skipPushState:true});
  }

})();
