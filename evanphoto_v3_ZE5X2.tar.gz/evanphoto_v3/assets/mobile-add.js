/* EvanPhoto mobile-add.js — v2.0.0 */
(function () {
  if (typeof EVANPHOTO_MOBILE_ADD === 'undefined') return;
  if (!EVANPHOTO_MOBILE_ADD.isLoggedIn) return;

  function el(tag, attrs, children) {
    var n = document.createElement(tag);
    if (attrs) Object.keys(attrs).forEach(function (k) {
      if (k === 'class')     n.className   = attrs[k];
      else if (k === 'html') n.innerHTML   = attrs[k];
      else                   n.setAttribute(k, attrs[k]);
    });
    (children || []).forEach(function (c) { n.appendChild(c); });
    return n;
  }

  var btn = el('button', {
    id: 'evanphoto-mobile-add-btn',
    type: 'button',
    'aria-label': '添加图片',
    html: '+'
  });
  document.body.appendChild(btn);

  var modal = el('div', { id: 'evanphoto-mobile-add-modal', 'class': 'hidden' });
  modal.innerHTML = [
    '<div class="overlay" data-close="1"></div>',
    '<div class="panel" role="dialog" aria-modal="true">',
      '<header>',
        '<div class="title">添加图片</div>',
        '<button type="button" data-close="1">×</button>',
      '</header>',
      '<div class="body">',
        '<div class="seg">',
          '<button type="button" data-mode="upload" class="active">上传</button>',
          '<button type="button" data-mode="url">URL</button>',
        '</div>',
        '<label>标题（可选）</label>',
        '<input type="text" name="title" placeholder="Photo title" />',
        '<div data-panel="upload">',
          '<label>选择图片</label>',
          '<input type="file" name="file" accept="image/*" />',
        '</div>',
        '<div data-panel="url" style="display:none;">',
          '<label>图片URL</label>',
          '<input type="url" name="external_url" placeholder="https://..." />',
        '</div>',
        '<div class="actions">',
          '<button type="button" class="secondary" data-close="1">取消</button>',
          '<button type="button" data-submit="1">提交</button>',
        '</div>',
        '<div class="hint" data-hint="1"></div>',
      '</div>',
      '<div class="progress" data-progress="1"><div class="bar" data-progress-bar="1"></div></div>',
    '</div>',
  ].join('');
  document.body.appendChild(modal);

  // ── helpers ──

  function progressEl()  { return modal.querySelector('[data-progress="1"]'); }
  function barEl()       { return modal.querySelector('[data-progress-bar="1"]'); }

  function setHint(t) {
    var h = modal.querySelector('[data-hint="1"]');
    if (h) h.textContent = t || '';
  }

  function progressHide() {
    var p = progressEl();
    if (!p) return;
    p.classList.remove('is-active', 'is-indeterminate');
    var b = barEl();
    if (b) b.style.width = '0%';
  }

  function progressIndeterminate(on) {
    var p = progressEl();
    if (!p) return;
    if (on) p.classList.add('is-active', 'is-indeterminate');
    else    p.classList.remove('is-indeterminate');
  }

  function progressSet(percent) {
    var p = progressEl();
    var b = barEl();
    if (!p || !b) return;
    p.classList.add('is-active');
    p.classList.remove('is-indeterminate');
    b.style.width = Math.max(0, Math.min(100, percent)).toFixed(0) + '%';
  }

  function open()  { modal.classList.remove('hidden'); }
  function close() { modal.classList.add('hidden'); setHint(''); progressHide(); }

  function setMode(mode) {
    modal.querySelectorAll('[data-mode]').forEach(function (b) {
      b.classList.toggle('active', b.getAttribute('data-mode') === mode);
    });
    modal.querySelector('[data-panel="upload"]').style.display = (mode === 'upload') ? '' : 'none';
    modal.querySelector('[data-panel="url"]').style.display    = (mode === 'url')    ? '' : 'none';
    modal.setAttribute('data-current-mode', mode);
    setHint('');
    progressHide();
  }

  // ── events ──

  btn.addEventListener('click', open);
  modal.addEventListener('click', function (e) {
    if (e.target && e.target.getAttribute && e.target.getAttribute('data-close') === '1') close();
  });
  modal.querySelectorAll('[data-mode]').forEach(function (b) {
    b.addEventListener('click', function () { setMode(b.getAttribute('data-mode')); });
  });

  // ── XHR upload with progress ──

  function postWithProgress(formData, opts) {
    return new Promise(function (resolve, reject) {
      var xhr = new XMLHttpRequest();
      xhr.open('POST', EVANPHOTO_MOBILE_ADD.restUrl, true);
      xhr.setRequestHeader('X-WP-Nonce', EVANPHOTO_MOBILE_ADD.nonce);

      xhr.upload.onprogress = function (e) {
        if (!e.lengthComputable) return;
        if (typeof (opts && opts.onUploadProgress) === 'function') {
          opts.onUploadProgress(e.loaded / e.total);
        }
      };

      xhr.onload = function () {
        try {
          var json = JSON.parse(xhr.responseText || '{}');
          resolve({ ok: xhr.status >= 200 && xhr.status < 300, status: xhr.status, json: json });
        } catch (e) {
          resolve({ ok: xhr.status >= 200 && xhr.status < 300, status: xhr.status, json: {} });
        }
      };

      xhr.onerror = function () { reject(new Error('Network error')); };
      xhr.send(formData);
    });
  }

  // ── submit ──

  async function submit() {
    var mode  = modal.getAttribute('data-current-mode') || 'upload';
    var title = (modal.querySelector('input[name="title"]') || {}).value || '';

    var fd = new FormData();
    fd.append('title', title);

    if (mode === 'url') {
      var url = (modal.querySelector('input[name="external_url"]') || {}).value || '';
      if (!url) { setHint('请填写图片URL'); return; }
      fd.append('source', 'external');
      fd.append('external_url', url);
      setHint('提交中…');
      progressIndeterminate(true);

      var res  = await fetch(EVANPHOTO_MOBILE_ADD.restUrl, {
        method: 'POST',
        headers: { 'X-WP-Nonce': EVANPHOTO_MOBILE_ADD.nonce },
        body: fd
      });
      var data = await res.json().catch(function () { return {}; });

      if (!res.ok || !data.ok) {
        progressHide();
        setHint((data && data.message) ? ('失败：' + data.message) : '失败');
        return;
      }
      progressHide();
      setHint('成功，刷新中…');
      window.location.href = window.location.origin + window.location.pathname;
      return;
    }

    // file upload
    var f = (modal.querySelector('input[name="file"]') || {}).files && modal.querySelector('input[name="file"]').files[0];
    if (!f) { setHint('请选择要上传的图片'); return; }
    fd.append('source', 'attachment');
    fd.append('file', f, f.name);
    setHint('上传中…');
    progressSet(0);

    var switchedToProcessing = false;
    var result = await postWithProgress(fd, {
      onUploadProgress: function (ratio) {
        progressSet(Math.min(90, Math.round(ratio * 90)));
        if (ratio >= 1 && !switchedToProcessing) {
          switchedToProcessing = true;
          setHint('处理中（方向校正 / 转WebP）…');
          progressIndeterminate(true);
        }
      }
    }).catch(function (err) {
      return { ok: false, json: { message: err.message || 'Network error' } };
    });

    if (!result.ok || !(result.json && result.json.ok)) {
      progressHide();
      setHint((result.json && result.json.message) ? ('失败：' + result.json.message) : '失败');
      return;
    }

    progressHide();
    setHint('成功，刷新中…');
    window.location.href = window.location.origin + window.location.pathname;
  }

  modal.querySelector('[data-submit="1"]').addEventListener('click', submit);

  // default mode
  setMode('upload');
})();
