<?php
if (!defined('ABSPATH')) { exit; }
get_header();

$images      = evanphoto_get_images();
$per_page    = evanphoto_get_thumbs_per_page();
$total       = count($images);
$total_pages = max(1, (int) ceil($total / $per_page));

$photo_id = null;
if (get_query_var('photo') !== '') {
    $photo_id = intval(get_query_var('photo'));
} elseif (isset($_GET['photo'])) {
    $photo_id = intval($_GET['photo']);
}

$paged = isset($_GET['pg']) ? max(1, intval($_GET['pg'])) : 1;

if ($photo_id !== null) {
    foreach ($images as $i => $img) {
        if (intval($img['id']) === $photo_id) {
            $paged = (int) floor($i / $per_page) + 1;
            break;
        }
    }
}

$paged = max(1, min($paged, $total_pages));
$offset      = ($paged - 1) * $per_page;
$page_images = array_slice($images, $offset, $per_page);

function evanphoto_page_url(int $pg) : string {
    return add_query_arg('pg', $pg, home_url('/'));
}

$copyright_html = evanphoto_get_copyright_html();
$hero_title     = evanphoto_get_hero_title();
$hero_desc      = evanphoto_get_hero_desc();
$hero_btn_text  = evanphoto_get_hero_button_text();
$hero_btn_url   = evanphoto_get_hero_button_url();
$hero_bg_url    = evanphoto_get_hero_bg_url();
$home_link_url  = evanphoto_get_home_link_url();
$hero_share_url = evanphoto_get_hero_share_url();
$share_brand    = evanphoto_get_share_brand();
$share_qr_url   = evanphoto_get_share_qr_url();
$hero_thumb     = !empty($images[0]['thumb_url']) ? $images[0]['thumb_url'] : '';

$window = evanphoto_get_pagination_window();
$half   = (int) floor($window / 2);
$start  = max(1, $paged - $half);
$end    = min($total_pages, $start + $window - 1);
$start  = max(1, $end - $window + 1);

$albums_enabled = evanphoto_albums_enabled();
?>

<main id="evanphoto-main" class="mx-auto max-w-[1960px] p-4">

  <?php if ($albums_enabled): ?>
  <div id="evanphoto-album-bar" class="evanphoto-album-bar" style="display:none;"></div>
  <?php endif; ?>

  <div id="evanphoto-grid" class="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4">

    <!-- ── Hero card ── -->
    <div class="evanphoto-hero after:content relative col-span-1 row-span-3 flex flex-col items-center justify-end gap-4 overflow-hidden rounded-lg bg-white/10 px-6 pb-16 pt-64 text-center text-white shadow-highlight after:pointer-events-none after:absolute after:inset-0 after:rounded-lg after:shadow-highlight sm:col-span-2 lg:col-span-1 lg:row-span-2 lg:pt-0">

      <?php if (trim($hero_bg_url) !== ''): ?>
        <div class="absolute inset-0" style="background-image:url('<?php echo esc_url($hero_bg_url); ?>'); background-size:cover; background-position:center; opacity:.25;"></div>
      <?php else: ?>
        <div class="absolute inset-0 flex items-center justify-center opacity-20">
          <span class="flex max-h-full max-w-full items-center justify-center">
            <?php $p = get_template_directory() . '/assets/conf-city.svg';
            if (file_exists($p)) echo file_get_contents($p); ?>
          </span>
          <span class="absolute left-0 bottom-0 flex max-h-full max-w-full items-center justify-center">
            <?php $p = get_template_directory() . '/assets/nextconf-logo.svg';
            if (file_exists($p)) echo file_get_contents($p); ?>
          </span>
        </div>
      <?php endif; ?>

      <?php if (trim($hero_share_url) !== ''): ?>
        <!-- Share button — absolute top-left of hero card -->
        <button
          class="evanphoto-share-trigger evanphoto-hero-share-topleft"
          type="button"
          aria-label="分享"
          data-share-type="hero"
          data-thumb="<?php echo esc_attr($hero_thumb); ?>"
          data-brand="<?php echo esc_attr($share_brand); ?>"
          data-qr-url="<?php echo esc_attr($share_qr_url); ?>"
          data-title="<?php echo esc_attr($hero_title); ?>"
        >
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" width="14" height="14" aria-hidden="true"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>
          <span>Share</span>
        </button>
      <?php endif; ?>

      <!-- Centred text block -->
      <div class="relative z-10">
        <h1 class="mt-4 text-3xl font-bold tracking-tight text-white sm:text-5xl"><?php echo esc_html($hero_title); ?></h1>
        <p class="mt-3 text-sm leading-6 text-white/60"><?php echo wp_kses_post($hero_desc); ?></p>
      </div>

      <!-- CTA button -->
      <a class="pointer z-10 rounded-lg border border-white bg-white px-3 py-2 text-sm font-semibold text-black transition hover:bg-white/10 hover:text-white"
         href="<?php echo esc_url($hero_btn_url); ?>" target="_blank" rel="noreferrer">
        <?php echo esc_html($hero_btn_text); ?>
      </a>



    </div><!-- /hero -->

    <!-- ── Thumbnail grid ── -->
    <?php foreach ($page_images as $img):
      $id         = intval($img['id']);
      $thumb      = $img['thumb_url'];
      $w          = intval($img['width']  ?? 0);
      $h          = intval($img['height'] ?? 0);
      $portrait   = !empty($img['is_portrait']);
      $photo_url  = home_url('/p/' . $id);
      $post_title = !empty($img['post_title']) ? $img['post_title'] : '';
    ?>
      <a
        class="after:content group relative cursor-zoom-in after:pointer-events-none after:absolute after:inset-0 after:rounded-lg after:shadow-highlight evanphoto-thumb-link"
        href="<?php echo esc_url($photo_url); ?>"
        data-photo-id="<?php echo esc_attr($id); ?>"
        data-portrait="<?php echo $portrait ? '1' : '0'; ?>"
        data-thumb="<?php echo esc_attr($thumb); ?>"
        data-brand="<?php echo esc_attr($share_brand); ?>"
        data-qr-url="<?php echo esc_attr($share_qr_url); ?>"
        data-title="<?php echo esc_attr($post_title); ?>"
        <?php if ($albums_enabled && !empty($img['album_id'])): ?>
          data-album-id="<?php echo esc_attr(intval($img['album_id'])); ?>"
        <?php endif; ?>
      >
        <span class="evanphoto-skeleton"></span>
        <img
          class="transform rounded-lg brightness-90 transition will-change-auto group-hover:brightness-110"
          src="<?php echo esc_url($thumb); ?>"
          <?php if ($w > 0): ?>width="<?php echo esc_attr($w); ?>"<?php endif; ?>
          <?php if ($h > 0): ?>height="<?php echo esc_attr($h); ?>"<?php endif; ?>
          loading="lazy"
          decoding="async"
          alt="<?php echo esc_attr($post_title); ?>"
          onload="this.previousElementSibling.style.display='none';"
        />
      </a>
    <?php endforeach; ?>

  </div><!-- /grid -->

  <!-- Pagination -->
  <?php if ($total_pages > 1): ?>
    <nav class="nextjsconf-pagination" aria-label="Pagination">
      <?php if ($paged > 1): ?>
        <a href="<?php echo esc_url(evanphoto_page_url($paged - 1)); ?>">Prev</a>
      <?php else: ?>
        <span class="is-disabled">Prev</span>
      <?php endif; ?>

      <?php for ($i = $start; $i <= $end; $i++): ?>
        <?php if ($i === $paged): ?>
          <span class="is-current"><?php echo esc_html($i); ?></span>
        <?php else: ?>
          <a href="<?php echo esc_url(evanphoto_page_url($i)); ?>"><?php echo esc_html($i); ?></a>
        <?php endif; ?>
      <?php endfor; ?>

      <?php if ($paged < $total_pages): ?>
        <a href="<?php echo esc_url(evanphoto_page_url($paged + 1)); ?>">Next</a>
      <?php else: ?>
        <span class="is-disabled">Next</span>
      <?php endif; ?>
    </nav>
  <?php endif; ?>

  <footer class="nextjsconf-copyright">
    <?php if (trim($copyright_html) !== ''): ?>
      <?php echo wp_kses_post($copyright_html); ?>
    <?php else: ?>
      &copy; <?php echo esc_html(date('Y')); ?> All rights reserved.
    <?php endif; ?>
  </footer>

</main>

<div id="nextjsconf-modal-root" class="hidden"></div>
<div id="evanphoto-share-overlay" class="hidden"></div>

<script>
  window.EVANPHOTO_INITIAL_PHOTO_ID = <?php echo ($photo_id === null ? 'null' : intval($photo_id)); ?>;
</script>

<?php get_footer(); ?>
