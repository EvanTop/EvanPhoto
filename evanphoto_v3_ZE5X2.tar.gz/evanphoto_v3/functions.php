<?php
/**
 * EvanPhoto theme functions.
 * Version: 2.0.0
 */

if (!defined('ABSPATH')) { exit; }

define('EVANPHOTO_VERSION', '2.4.0');
define('EVANPHOTO_CPT', 'evanphoto_photo');

define('EVANPHOTO_META_SOURCE',        '_evanphoto_source');        // 'external' | 'attachment'
define('EVANPHOTO_META_ATTACHMENT_ID', '_evanphoto_attachment_id');
define('EVANPHOTO_META_EXTERNAL_URL',  '_evanphoto_external_url');
define('EVANPHOTO_META_ORIG_ID',       '_evanphoto_orig_id');       // imported numeric id (0..n)
define('EVANPHOTO_META_MARKED',        '_evanphoto_marked');        // 0/1
define('EVANPHOTO_META_IS_IMPORTED',   '_evanphoto_is_imported');   // 0/1
define('EVANPHOTO_META_WIDTH',         '_evanphoto_width');         // cached image width
define('EVANPHOTO_META_HEIGHT',        '_evanphoto_height');        // cached image height
define('EVANPHOTO_META_EXIF_JSON',     '_evanphoto_exif');          // serialised EXIF subset
define('EVANPHOTO_META_ALBUM',         '_evanphoto_album_id');      // term id (when albums enabled)

// ─────────────────────────────────────────
// Theme setup
// ─────────────────────────────────────────

function evanphoto_theme_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', ['search-form','comment-form','comment-list','gallery','caption','style','script']);

    add_image_size('evanphoto_thumb_720',    720, 0, false);
    add_image_size('evanphoto_display_1280', 1280, 0, false);
}
add_action('after_setup_theme', 'evanphoto_theme_setup');

// ─────────────────────────────────────────
// CPT
// ─────────────────────────────────────────

function evanphoto_register_cpt() {
    $labels = [
        'name'          => '图片',
        'singular_name' => '图片',
        'add_new'       => '添加图片',
        'add_new_item'  => '添加图片',
        'edit_item'     => '编辑图片',
        'new_item'      => '新图片',
        'view_item'     => '查看图片',
        'search_items'  => '搜索图片',
        'not_found'     => '未找到图片',
        'menu_name'     => '图片',
    ];

    register_post_type(EVANPHOTO_CPT, [
        'labels'        => $labels,
        'public'        => false,
        'show_ui'       => true,
        'show_in_menu'  => true,
        'menu_position' => 5,
        'menu_icon'     => 'dashicons-format-gallery',
        'supports'      => ['title'],
        'capability_type' => 'post',
        'has_archive'   => false,
    ]);
}
add_action('init', 'evanphoto_register_cpt');

// ─────────────────────────────────────────
// Album taxonomy (registered always, UI shown only when enabled)
// ─────────────────────────────────────────

function evanphoto_register_album_taxonomy() {
    $labels = [
        'name'          => '相册',
        'singular_name' => '相册',
        'add_new_item'  => '新建相册',
        'edit_item'     => '编辑相册',
        'update_item'   => '更新相册',
        'search_items'  => '搜索相册',
        'not_found'     => '未找到相册',
        'menu_name'     => '相册',
    ];

    $albums_enabled = evanphoto_albums_enabled();

    register_taxonomy('evanphoto_album', EVANPHOTO_CPT, [
        'labels'            => $labels,
        'public'            => false,
        'show_ui'           => $albums_enabled,
        'show_in_menu'      => $albums_enabled,
        'show_admin_column' => $albums_enabled,
        'hierarchical'      => true,
        'rewrite'           => false,
    ]);
}
add_action('init', 'evanphoto_register_album_taxonomy');

function evanphoto_albums_enabled() : bool {
    return (bool) get_theme_mod('evanphoto_albums_enabled', false);
}

// ─────────────────────────────────────────
// Admin assets
// ─────────────────────────────────────────

function evanphoto_admin_assets($hook) {
    $screen = function_exists('get_current_screen') ? get_current_screen() : null;
    if (!$screen) return;
    if ($screen->post_type !== EVANPHOTO_CPT) return;

    wp_enqueue_media();
    wp_enqueue_script('evanphoto-admin', get_template_directory_uri() . '/assets/admin.js', ['jquery'], EVANPHOTO_VERSION, true);
}
add_action('admin_enqueue_scripts', 'evanphoto_admin_assets');

// ─────────────────────────────────────────
// Meta boxes
// ─────────────────────────────────────────

function evanphoto_add_metaboxes() {
    add_meta_box(
        'evanphoto_photo_source',
        '图片来源',
        'evanphoto_metabox_render',
        EVANPHOTO_CPT,
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'evanphoto_add_metaboxes');

function evanphoto_metabox_render($post) {
    wp_nonce_field('evanphoto_photo_save', 'evanphoto_photo_nonce');

    $source        = get_post_meta($post->ID, EVANPHOTO_META_SOURCE, true) ?: 'attachment';
    $attachment_id = intval(get_post_meta($post->ID, EVANPHOTO_META_ATTACHMENT_ID, true));
    $external_url  = (string) get_post_meta($post->ID, EVANPHOTO_META_EXTERNAL_URL, true);
    $marked        = intval(get_post_meta($post->ID, EVANPHOTO_META_MARKED, true)) === 1;
    $attachment_url = $attachment_id ? wp_get_attachment_url($attachment_id) : '';

    // EXIF display
    $exif_raw = get_post_meta($post->ID, EVANPHOTO_META_EXIF_JSON, true);
    $exif     = $exif_raw ? json_decode($exif_raw, true) : [];
    ?>
    <style>
        .evanphoto-row { margin: 10px 0; }
        .evanphoto-row label { display:block; font-weight: 600; margin-bottom: 6px; }
        .evanphoto-inline { display:flex; gap:10px; align-items:center; flex-wrap:wrap; }
        .evanphoto-preview { margin-top: 8px; }
        .evanphoto-preview img { max-width: 260px; height: auto; border-radius: 6px; }
        .evanphoto-help { color:#666; font-size: 12px; }
        .evanphoto-exif { font-size:12px; color:#555; margin-top:8px; line-height:1.8; }
    </style>

    <div class="evanphoto-row">
        <label>来源类型</label>
        <div class="evanphoto-inline">
            <label><input type="radio" name="evanphoto_source" value="attachment" <?php checked($source, 'attachment'); ?> /> 上传到媒体库（Media）</label>
            <label><input type="radio" name="evanphoto_source" value="external" <?php checked($source, 'external'); ?> /> 外链图片（直接URL）</label>
        </div>
        <div class="evanphoto-help">无论媒体库或外链，保存后都会显示在首页画廊的第一页（按添加时间优先）。</div>
    </div>

    <div class="evanphoto-row" data-source-panel="attachment" style="<?php echo $source === 'attachment' ? '' : 'display:none;'; ?>">
        <label>媒体库图片</label>
        <div class="evanphoto-inline">
            <input type="hidden" name="evanphoto_attachment_id" id="evanphoto_attachment_id" value="<?php echo esc_attr($attachment_id); ?>" />
            <button type="button" class="button" id="evanphoto_pick_media">选择/上传图片</button>
            <button type="button" class="button" id="evanphoto_clear_media">清除</button>
            <?php if ($attachment_url): ?>
                <a href="<?php echo esc_url($attachment_url); ?>" target="_blank" rel="noreferrer">查看原图</a>
            <?php endif; ?>
        </div>
        <div class="evanphoto-preview" id="evanphoto_media_preview" style="<?php echo $attachment_url ? '' : 'display:none;'; ?>">
            <?php if ($attachment_url): ?>
                <img src="<?php echo esc_url($attachment_url); ?>" alt="" />
            <?php endif; ?>
        </div>
    </div>

    <div class="evanphoto-row" data-source-panel="external" style="<?php echo $source === 'external' ? '' : 'display:none;'; ?>">
        <label>外链URL</label>
        <input type="url" name="evanphoto_external_url" value="<?php echo esc_attr($external_url); ?>" class="widefat" placeholder="https://..." />
        <div class="evanphoto-preview" id="evanphoto_external_preview" style="<?php echo $external_url ? '' : 'display:none;'; ?>">
            <?php if ($external_url): ?>
                <img src="<?php echo esc_url($external_url); ?>" alt="" />
            <?php endif; ?>
        </div>
        <div class="evanphoto-help">支持任意常见图片格式（jpg/png/webp/gif等）。</div>
    </div>

    <div class="evanphoto-row">
        <label><input type="checkbox" name="evanphoto_marked" value="1" <?php checked($marked, true); ?> /> 标记</label>
        <div class="evanphoto-help">用于后台快速筛选/标记（不影响前台展示逻辑）。</div>
    </div>

    <?php if (!empty($exif)): ?>
    <div class="evanphoto-row">
        <label>EXIF 信息</label>
        <div class="evanphoto-exif">
            <?php foreach ($exif as $k => $v): ?>
                <span><strong><?php echo esc_html($k); ?>：</strong><?php echo esc_html($v); ?></span>&emsp;
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>
    <?php
}

// ─────────────────────────────────────────
// Save post
// ─────────────────────────────────────────

function evanphoto_save_post($post_id) {
    if (get_post_type($post_id) !== EVANPHOTO_CPT) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!isset($_POST['evanphoto_photo_nonce']) || !wp_verify_nonce($_POST['evanphoto_photo_nonce'], 'evanphoto_photo_save')) return;
    if (!current_user_can('edit_post', $post_id)) return;

    $source = isset($_POST['evanphoto_source']) ? sanitize_text_field($_POST['evanphoto_source']) : 'attachment';
    if (!in_array($source, ['external','attachment'], true)) $source = 'attachment';
    update_post_meta($post_id, EVANPHOTO_META_SOURCE, $source);

    $marked = isset($_POST['evanphoto_marked']) ? 1 : 0;
    update_post_meta($post_id, EVANPHOTO_META_MARKED, $marked);

    if (get_post_meta($post_id, EVANPHOTO_META_IS_IMPORTED, true) === '') {
        update_post_meta($post_id, EVANPHOTO_META_IS_IMPORTED, 0);
    }

    if ($source === 'attachment') {
        $attachment_id = isset($_POST['evanphoto_attachment_id']) ? intval($_POST['evanphoto_attachment_id']) : 0;
        if ($attachment_id > 0) {
            update_post_meta($post_id, EVANPHOTO_META_ATTACHMENT_ID, $attachment_id);
        } else {
            delete_post_meta($post_id, EVANPHOTO_META_ATTACHMENT_ID);
        }
        delete_post_meta($post_id, EVANPHOTO_META_EXTERNAL_URL);
    } else {
        $external_url = isset($_POST['evanphoto_external_url']) ? esc_url_raw($_POST['evanphoto_external_url']) : '';
        if ($external_url) {
            update_post_meta($post_id, EVANPHOTO_META_EXTERNAL_URL, $external_url);
            // Try to cache dimensions for external images
            evanphoto_cache_external_dimensions($post_id, $external_url);
        } else {
            delete_post_meta($post_id, EVANPHOTO_META_EXTERNAL_URL);
        }
        delete_post_meta($post_id, EVANPHOTO_META_ATTACHMENT_ID);
    }
}
add_action('save_post', 'evanphoto_save_post');

/**
 * Attempt to fetch & cache width/height for an external image URL.
 * Uses getimagesize() — may fail for remote URLs without allow_url_fopen.
 */
function evanphoto_cache_external_dimensions(int $post_id, string $url) : void {
    // Only run if we don't already have dimensions
    $existing_w = get_post_meta($post_id, EVANPHOTO_META_WIDTH, true);
    if ($existing_w !== '') return;

    if (!function_exists('getimagesize')) return;
    $info = @getimagesize($url);
    if ($info && isset($info[0], $info[1]) && $info[0] > 0) {
        update_post_meta($post_id, EVANPHOTO_META_WIDTH,  intval($info[0]));
        update_post_meta($post_id, EVANPHOTO_META_HEIGHT, intval($info[1]));
    }
}

// ─────────────────────────────────────────
// Admin columns
// ─────────────────────────────────────────

function evanphoto_admin_columns($cols) {
    $cols['evanphoto_source'] = '来源';
    $cols['evanphoto_marked'] = '标记';
    return $cols;
}
add_filter('manage_' . EVANPHOTO_CPT . '_posts_columns', 'evanphoto_admin_columns');

function evanphoto_admin_column_content($col, $post_id) {
    if ($col === 'evanphoto_source') {
        $source = get_post_meta($post_id, EVANPHOTO_META_SOURCE, true);
        echo $source === 'attachment' ? '媒体库' : '外链';
    }
    if ($col === 'evanphoto_marked') {
        $marked = intval(get_post_meta($post_id, EVANPHOTO_META_MARKED, true)) === 1;
        echo $marked ? '✅' : '';
    }
}
add_action('manage_' . EVANPHOTO_CPT . '_posts_custom_column', 'evanphoto_admin_column_content', 10, 2);

// ─────────────────────────────────────────
// Import existing Cloudinary list (run once)
// ─────────────────────────────────────────

function evanphoto_import_from_json_once() {
    if (get_option('evanphoto_imported_v1') === '1') return;

    $path = get_template_directory() . '/data/images.json';
    if (!file_exists($path)) { update_option('evanphoto_imported_v1', '1'); return; }

    $raw   = file_get_contents($path);
    $items = json_decode($raw, true);
    if (!is_array($items)) { update_option('evanphoto_imported_v1', '1'); return; }

    $existing = [];
    $q = new WP_Query([
        'post_type'      => EVANPHOTO_CPT,
        'post_status'    => 'any',
        'posts_per_page' => -1,
        'fields'         => 'ids',
        'meta_key'       => EVANPHOTO_META_ORIG_ID,
    ]);
    foreach ($q->posts as $pid) {
        $oid = get_post_meta($pid, EVANPHOTO_META_ORIG_ID, true);
        if ($oid !== '') $existing[intval($oid)] = $pid;
    }

    foreach ($items as $img) {
        $id = intval($img['id'] ?? -1);
        if ($id < 0) continue;
        if (isset($existing[$id])) continue;

        $public_id = (string)($img['public_id'] ?? '');
        $format    = (string)($img['format']    ?? 'jpg');
        if (!$public_id) continue;

        $full = 'https://res.cloudinary.com/zeit-inc/image/upload/' . $public_id . '.' . $format;

        $post_id = wp_insert_post([
            'post_type'   => EVANPHOTO_CPT,
            'post_status' => 'publish',
            'post_title'  => 'Photo ' . $id,
        ]);
        if (is_wp_error($post_id) || !$post_id) continue;

        update_post_meta($post_id, EVANPHOTO_META_ORIG_ID,     $id);
        update_post_meta($post_id, EVANPHOTO_META_IS_IMPORTED, 1);
        update_post_meta($post_id, EVANPHOTO_META_SOURCE,      'external');
        update_post_meta($post_id, EVANPHOTO_META_EXTERNAL_URL, $full);
        update_post_meta($post_id, EVANPHOTO_META_MARKED,      0);

        // Cache dimensions from json if available
        $w = intval($img['width']  ?? 0);
        $h = intval($img['height'] ?? 0);
        if ($w > 0) update_post_meta($post_id, EVANPHOTO_META_WIDTH,  $w);
        if ($h > 0) update_post_meta($post_id, EVANPHOTO_META_HEIGHT, $h);
    }

    update_option('evanphoto_imported_v1', '1');
}
add_action('admin_init', 'evanphoto_import_from_json_once');

// ─────────────────────────────────────────
// EXIF extraction helper
// ─────────────────────────────────────────

/**
 * Extract a subset of EXIF data and return as assoc array.
 * Returns empty array if EXIF is unavailable or unreadable.
 */
function evanphoto_extract_exif(string $file_path) : array {
    if (!function_exists('exif_read_data')) return [];
    $exif = @exif_read_data($file_path);
    if (!is_array($exif)) return [];

    $result = [];

    $make  = trim($exif['Make'] ?? '');
    $model = trim($exif['Model'] ?? '');
    if ($make || $model) {
        // Remove duplicate Make prefix in Model (e.g. "Canon Canon EOS …")
        if ($make && strpos($model, $make) === 0) {
            $result['相机'] = trim($model);
        } else {
            $result['相机'] = trim($make . ' ' . $model);
        }
    }

    if (!empty($exif['DateTimeOriginal'])) {
        $result['拍摄时间'] = $exif['DateTimeOriginal'];
    }

    if (!empty($exif['FocalLength'])) {
        $fl = evanphoto_exif_fraction($exif['FocalLength']);
        if ($fl !== null) $result['焦距'] = round($fl) . 'mm';
    }

    if (!empty($exif['FNumber'])) {
        $fn = evanphoto_exif_fraction($exif['FNumber']);
        if ($fn !== null) $result['光圈'] = 'f/' . $fn;
    }

    if (!empty($exif['ExposureTime'])) {
        $et = evanphoto_exif_fraction($exif['ExposureTime']);
        if ($et !== null) {
            if ($et >= 1) {
                $result['快门'] = $et . 's';
            } else {
                $result['快门'] = '1/' . round(1 / $et) . 's';
            }
        }
    }

    if (!empty($exif['ISOSpeedRatings'])) {
        $iso = is_array($exif['ISOSpeedRatings']) ? $exif['ISOSpeedRatings'][0] : $exif['ISOSpeedRatings'];
        $result['ISO'] = 'ISO' . intval($iso);
    }

    return $result;
}

/**
 * Convert a rational string "num/denom" or plain number to float. Returns null on failure.
 */
function evanphoto_exif_fraction($val) : ?float {
    if (is_numeric($val)) return floatval($val);
    if (is_string($val) && strpos($val, '/') !== false) {
        [$n, $d] = explode('/', $val, 2);
        $d = floatval($d);
        if ($d == 0) return null;
        return floatval($n) / $d;
    }
    return null;
}

/**
 * Get the correct rotation angle (degrees CCW) needed to make image upright.
 * Returns 0 if no rotation needed.
 */
function evanphoto_exif_orientation_angle(string $file_path) : int {
    if (!function_exists('exif_read_data')) return 0;
    $exif = @exif_read_data($file_path);
    if (!is_array($exif) || empty($exif['Orientation'])) return 0;

    switch (intval($exif['Orientation'])) {
        case 3: return 180;
        case 6: return 270; // 90 CW → need CCW 270
        case 8: return 90;  // 90 CCW → need CCW 90
        default: return 0;
    }
}

// ─────────────────────────────────────────
// Frontend images list
// ─────────────────────────────────────────

/**
 * Returns all published photos as an array.
 * Uses meta cache pre-warming to avoid N+1 queries.
 *
 * Each item: [
 *   id, thumb_url, display_url, full_url,
 *   width, height,            // actual pixel dimensions (portrait = h > w)
 *   is_portrait,              // 1 if height > width
 *   is_imported,
 *   exif,                     // assoc array of EXIF fields (may be empty)
 *   album_id, album_name,     // populated when albums enabled
 * ]
 */
function evanphoto_get_images() : array {
    $posts = get_posts([
        'post_type'      => EVANPHOTO_CPT,
        'post_status'    => 'publish',
        'posts_per_page' => -1,
        'orderby'        => 'date',
        'order'          => 'DESC',
    ]);

    if (empty($posts)) return [];

    // ── Pre-warm post meta cache (eliminates N+1 queries) ──
    $ids = wp_list_pluck($posts, 'ID');
    update_meta_cache('post', $ids);

    $albums_enabled = evanphoto_albums_enabled();

    $custom   = [];
    $imported = [];

    foreach ($posts as $p) {
        $is_imported = intval(get_post_meta($p->ID, EVANPHOTO_META_IS_IMPORTED, true)) === 1;
        $source      = get_post_meta($p->ID, EVANPHOTO_META_SOURCE, true) ?: 'attachment';

        $id = $is_imported
            ? intval(get_post_meta($p->ID, EVANPHOTO_META_ORIG_ID, true))
            : intval($p->ID);

        $item = [
            'id'          => $id,
            'thumb_url'   => '',
            'display_url' => '',
            'full_url'    => '',
            'width'       => 0,
            'height'      => 0,
            'is_portrait' => 0,
            'is_imported' => $is_imported ? 1 : 0,
            'post_title'  => ($is_imported ? '' : (string) $p->post_title),
            'exif'        => [],
            'album_id'    => 0,
            'album_name'  => '',
        ];

        if ($source === 'attachment') {
            $aid = intval(get_post_meta($p->ID, EVANPHOTO_META_ATTACHMENT_ID, true));
            if ($aid <= 0) continue;

            $thumb   = wp_get_attachment_image_url($aid, 'evanphoto_thumb_720')
                    ?: wp_get_attachment_image_url($aid, 'large');
            $display = wp_get_attachment_image_url($aid, 'evanphoto_display_1280')
                    ?: wp_get_attachment_image_url($aid, 'full');
            $full    = wp_get_attachment_image_url($aid, 'full');

            $meta = wp_get_attachment_metadata($aid);
            $w    = isset($meta['width'])  ? intval($meta['width'])  : 0;
            $h    = isset($meta['height']) ? intval($meta['height']) : 0;

            $item['thumb_url']   = $thumb;
            $item['display_url'] = $display;
            $item['full_url']    = $full;
            $item['width']       = $w;
            $item['height']      = $h;
            $item['is_portrait'] = ($h > $w && $w > 0) ? 1 : 0;
        } else {
            $url = (string) get_post_meta($p->ID, EVANPHOTO_META_EXTERNAL_URL, true);
            if (!$url) continue;

            $w = intval(get_post_meta($p->ID, EVANPHOTO_META_WIDTH,  true));
            $h = intval(get_post_meta($p->ID, EVANPHOTO_META_HEIGHT, true));

            $item['thumb_url']   = $url;
            $item['display_url'] = $url;
            $item['full_url']    = $url;
            $item['width']       = $w;
            $item['height']      = $h;
            $item['is_portrait'] = ($h > $w && $w > 0) ? 1 : 0;
        }

        // EXIF
        $exif_raw = get_post_meta($p->ID, EVANPHOTO_META_EXIF_JSON, true);
        if ($exif_raw) {
            $item['exif'] = json_decode($exif_raw, true) ?: [];
        }

        // Album
        if ($albums_enabled) {
            $terms = get_the_terms($p->ID, 'evanphoto_album');
            if ($terms && !is_wp_error($terms)) {
                $term = reset($terms);
                $item['album_id']   = intval($term->term_id);
                $item['album_name'] = $term->name;
            }
        }

        if ($is_imported) {
            $imported[] = $item;
        } else {
            $custom[] = $item;
        }
    }

    usort($imported, fn($a,$b) => intval($a['id']) <=> intval($b['id']));

    return array_merge($custom, $imported);
}

// ─────────────────────────────────────────
// Theme mod helpers
// ─────────────────────────────────────────

function evanphoto_get_thumbs_per_page() : int {
    $v = intval(get_theme_mod('evanphoto_thumbs_per_page', 60));
    if ($v < 4)    $v = 4;
    if ($v > 9999) $v = 9999;
    return $v;
}

function evanphoto_get_pagination_window() : int {
    $v = intval(get_theme_mod('evanphoto_pagination_window', 9));
    if ($v < 3)  $v = 3;
    if ($v > 99) $v = 99;
    if ($v % 2 === 0) $v += 1;
    return $v;
}

function evanphoto_get_copyright_html() : string {
    return (string) get_theme_mod('evanphoto_copyright', '© 2026 All rights reserved. By <a href="https://evan.xin" target="_blank" class="footer-link">Evan</a>');
}

function evanphoto_get_hero_title() : string {
    return (string) get_theme_mod('evanphoto_hero_title', 'TimePhoto');
}

function evanphoto_get_hero_desc() : string {
    return (string) get_theme_mod('evanphoto_hero_desc', '当下即是・无欠无余');
}

function evanphoto_get_hero_button_text() : string {
    return (string) get_theme_mod('evanphoto_hero_button_text', '2026 Time\'s Photo');
}

function evanphoto_get_hero_button_url() : string {
    return (string) get_theme_mod('evanphoto_hero_button_url', 'https://evan.xin');
}

function evanphoto_get_hero_bg_url() : string {
    return (string) get_theme_mod('evanphoto_hero_bg_url', '');
}

// Home link (shown in hero card bottom bar)
function evanphoto_get_home_link_url() : string {
    return (string) get_theme_mod('evanphoto_home_link_url', 'https://evan.xin');
}

// QR code for https://time.photo — pre-generated PNG, embedded as data URI
// White modules on transparent background (198×198 px, RGBA)
define('EVANPHOTO_QR_DATA_URI', 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMYAAADGCAYAAACJm/9dAAADD0lEQVR42u3dUY7qMAxA0XbU/W+ZWUFAqWxsl3O+ETDtuy/ICuE4AAAAAAAAAAAAAAAAAAAAAAAAeIIz+wVer9drxIU4zzPi71o9T9R12H2f7tc9f/5vAGGAMEAYIAzIdVW9cPZUYWV36rI7fcq+DtnvZ/r9smKAMEAYIAwQBgxxdXtD3fYUZe99yp4yVT1/1f2yYoAwQBggDBAGDHG5BPdE7XHaffzu63ab9lgxQBggDBAGCAM4jsNU6qPdadJqCjR9z5UVAxAGCAOEAcKAUO2mUt2mKFHTpKjT0btNn5469bJigDBAGCAMEAYkK5tKTfmtt6hpUvbjo97/9PtlxQBhgDBAGCAMGMK3u26qOuU7e+qFFQOEAcIAYYAw4CvSJxNT9hpNmdJEnXNVdX+zn8eKAcIAYYAwQBgwRNkkZvq0Kvubd8sbFvT806dw2e/figHCAGGAMEAYkCz9XKlfmz7tijrtfPr9smKAMEAYIAwQBvwYe6WCH7+80EXPM2VvlW/wgY9SIAwQBggDfoxzpYIfn30dljey2anp06dkVgwQBggDhAHCgGT2Sn3p8dnXbfvGOwXdigHCAGGAMEAYUMleqWGP373OyxtfNB2aMlWzYoAwQBggDBAGJLNXqvjvinr+5Q1udp5V1XWzYoAwQBggDBAGNGOv1IfH7/5dyws95Lym9H9wRVMmKwYIA4QBwgBhQDOnS/Bet9POu50W3m3vlhUDhAHCAGGAMGCIK/sFuu3VWVlNObrt7cm+nt2+SWfFAGGAMEAYIAx4qKvqhaumHFVTnajHdzsF3YoBwgBhAMIAYcAtV7c31O032rL3Du1+oy3q+kw5b6rqfVoxQBggDBAGCAOSXS7Be1W/8Vd1/lK3bwj6DT7wUQqEAcIAYcBDmUp9kD19iprSZE+TqqZzVedcWTFAGCAMEAYIA5K1m0p1O9coe89S9m/57T5PlOzfHLRigDBAGCAMEAYMVzaVmvLbfFP2AlV9sy97amSvFPgoBcIAYYAwAAAAAAAAAAAAAAAAAAAAAAAAABr7B7zZWVjY0Sk8AAAAAElFTkSuQmCC');

// Share button next to Home (optional — empty = hidden)
function evanphoto_get_hero_share_url() : string {
    return (string) get_theme_mod('evanphoto_hero_share_url', '');
}

// Brand name shown on generated share cards
function evanphoto_get_share_brand() : string {
    return (string) get_theme_mod('evanphoto_share_brand', 'Time.Photo');
}

// QR code target URL
function evanphoto_get_share_qr_url() : string {
    return (string) get_theme_mod('evanphoto_share_qr_url', 'https://time.photo');
}

// ─────────────────────────────────────────
// Enqueue assets
// ─────────────────────────────────────────

function evanphoto_enqueue_assets() {
    wp_enqueue_style('evanphoto-base',  get_template_directory_uri() . '/assets/nextjsconf.css', [],                   EVANPHOTO_VERSION);
    wp_enqueue_style('evanphoto-style', get_stylesheet_uri(),                                      ['evanphoto-base'],   EVANPHOTO_VERSION);

    wp_enqueue_script('evanphoto-gallery', get_template_directory_uri() . '/assets/gallery.js', [], EVANPHOTO_VERSION, true);

    $images   = evanphoto_get_images();
    $per_page = evanphoto_get_thumbs_per_page();

    wp_localize_script('evanphoto-gallery', 'EVANPHOTO', [
        'images'          => $images,
        'perPage'         => $per_page,
        'baseUrl'         => home_url('/'),
        'photoPathPrefix' => home_url('/p/'),
        'paginationWindow'=> evanphoto_get_pagination_window(),
        'albumsEnabled'   => evanphoto_albums_enabled() ? 1 : 0,
        'shareBrand'      => evanphoto_get_share_brand(),
        'shareQrUrl'      => evanphoto_get_share_qr_url(),
        'heroShareUrl'    => evanphoto_get_hero_share_url(),
        'heroTitle'       => evanphoto_get_hero_title(),
        'siteThumbUrl'    => '', // populated by JS from first grid image if empty
        'qrDataUri'       => EVANPHOTO_QR_DATA_URI,
    ]);

    if (is_user_logged_in()) {
        wp_enqueue_script('evanphoto-mobile-add', get_template_directory_uri() . '/assets/mobile-add.js', [], EVANPHOTO_VERSION, true);
        wp_localize_script('evanphoto-mobile-add', 'EVANPHOTO_MOBILE_ADD', [
            'restUrl'   => rest_url('evanphoto/v1/photo'),
            'nonce'     => wp_create_nonce('wp_rest'),
            'isLoggedIn'=> true,
        ]);
    }
}
add_action('wp_enqueue_scripts', 'evanphoto_enqueue_assets');

// ─────────────────────────────────────────
// Customizer
// ─────────────────────────────────────────

function evanphoto_customize_register($wp_customize) {

    // ── EvanPhoto section ──
    $wp_customize->add_section('evanphoto_section', [
        'title'    => 'EvanPhoto',
        'priority' => 30,
    ]);

    // Thumbs per page
    $wp_customize->add_setting('evanphoto_thumbs_per_page', [
        'default'           => 60,
        'sanitize_callback' => function($v){ $v=intval($v); return max(4,min(9999,$v)); },
    ]);
    $wp_customize->add_control('evanphoto_thumbs_per_page', [
        'label'       => '每页显示图片缩略图数量',
        'section'     => 'evanphoto_section',
        'type'        => 'number',
        'input_attrs' => ['min'=>4,'max'=>9999,'step'=>1],
    ]);

    // Pagination window
    $wp_customize->add_setting('evanphoto_pagination_window', [
        'default'           => 9,
        'sanitize_callback' => function($v){ $v=intval($v); $v=max(3,min(99,$v)); if($v%2===0)$v++; return $v; },
    ]);
    $wp_customize->add_control('evanphoto_pagination_window', [
        'label'       => '翻页中间显示页码数量（默认9）',
        'section'     => 'evanphoto_section',
        'type'        => 'number',
        'input_attrs' => ['min'=>3,'max'=>99,'step'=>1],
    ]);

    // Hero title
    $wp_customize->add_setting('evanphoto_hero_title', [
        'default'           => 'TimePhoto',
        'sanitize_callback' => 'sanitize_text_field',
    ]);
    $wp_customize->add_control('evanphoto_hero_title', [
        'label'   => '左上角标题',
        'section' => 'evanphoto_section',
        'type'    => 'text',
    ]);

    // Hero desc
    $wp_customize->add_setting('evanphoto_hero_desc', [
        'default'           => '当下即是・无欠无余',
        'sanitize_callback' => 'wp_kses_post',
    ]);
    $wp_customize->add_control('evanphoto_hero_desc', [
        'label'   => '左上角描述',
        'section' => 'evanphoto_section',
        'type'    => 'textarea',
    ]);

    // Hero button text
    $wp_customize->add_setting('evanphoto_hero_button_text', [
        'default'           => "2026 Time's Photo",
        'sanitize_callback' => 'sanitize_text_field',
    ]);
    $wp_customize->add_control('evanphoto_hero_button_text', [
        'label'   => '左上角按钮文字',
        'section' => 'evanphoto_section',
        'type'    => 'text',
    ]);

    // Hero button URL
    $wp_customize->add_setting('evanphoto_hero_button_url', [
        'default'           => 'https://evan.xin',
        'sanitize_callback' => 'esc_url_raw',
    ]);
    $wp_customize->add_control('evanphoto_hero_button_url', [
        'label'   => '左上角按钮链接',
        'section' => 'evanphoto_section',
        'type'    => 'url',
    ]);

    // Hero bg
    $wp_customize->add_setting('evanphoto_hero_bg_url', [
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
    ]);
    $wp_customize->add_control('evanphoto_hero_bg_url', [
        'label'   => '左上角背景图URL（留空=默认样式）',
        'section' => 'evanphoto_section',
        'type'    => 'url',
    ]);

    // Home link URL

    // Hero share URL (optional — shown next to Home when non-empty)
    $wp_customize->add_setting('evanphoto_hero_share_url', [
        'default'           => '',
        'sanitize_callback' => 'esc_url_raw',
    ]);
    $wp_customize->add_control('evanphoto_hero_share_url', [
        'label'       => '首页分享按钮链接（留空=不显示分享按钮）',
        'section'     => 'evanphoto_section',
        'type'        => 'url',
        'description' => '填写后，Home 右侧出现一个分享图标，点击会生成包含首页缩略图和二维码的分享卡片。',
    ]);

    // Share brand name
    $wp_customize->add_setting('evanphoto_share_brand', [
        'default'           => 'Time.Photo',
        'sanitize_callback' => 'sanitize_text_field',
    ]);
    $wp_customize->add_control('evanphoto_share_brand', [
        'label'       => '分享卡片品牌名称',
        'section'     => 'evanphoto_section',
        'type'        => 'text',
        'description' => '显示在生成的分享图片中，默认 Time.Photo',
    ]);

    // Share QR URL
    $wp_customize->add_setting('evanphoto_share_qr_url', [
        'default'           => 'https://time.photo',
        'sanitize_callback' => 'esc_url_raw',
    ]);
    $wp_customize->add_control('evanphoto_share_qr_url', [
        'label'       => '分享卡片二维码网址',
        'section'     => 'evanphoto_section',
        'type'        => 'url',
        'description' => '生成的分享图片中二维码所对应的网址，默认 https://time.photo',
    ]);

    // Copyright
    $wp_customize->add_setting('evanphoto_copyright', [
        'default'           => '© 2026 All rights reserved. By <a href="https://evan.xin" target="_blank" class="footer-link">Evan</a>',
        'sanitize_callback' => 'wp_kses_post',
    ]);
    $wp_customize->add_control('evanphoto_copyright', [
        'label'       => '版权信息（支持HTML）',
        'section'     => 'evanphoto_section',
        'type'        => 'textarea',
    ]);

    // Albums toggle (default OFF)
    $wp_customize->add_setting('evanphoto_albums_enabled', [
        'default'           => false,
        'sanitize_callback' => function($v){ return (bool)$v; },
    ]);
    $wp_customize->add_control('evanphoto_albums_enabled', [
        'label'       => '启用相册分组功能（默认关闭）',
        'section'     => 'evanphoto_section',
        'type'        => 'checkbox',
        'description' => '开启后可在图片编辑页面将照片归属到相册，前台支持按相册筛选。',
    ]);

    // ── Analytics section ──
    $wp_customize->add_section('analytics_section', [
        'title'    => '统计代码',
        'priority' => 200,
    ]);

    $wp_customize->add_setting('umami_website_id', [
        'default'           => '',
        'sanitize_callback' => 'sanitize_text_field',
    ]);
    $wp_customize->add_control('umami_website_id', [
        'label'   => 'Umami Website ID',
        'section' => 'analytics_section',
        'type'    => 'text',
    ]);
}
add_action('customize_register', 'evanphoto_customize_register');

// ─────────────────────────────────────────
// Umami analytics
// ─────────────────────────────────────────

function evanphoto_output_umami_script() {
    $website_id = get_theme_mod('umami_website_id', '');
    if (empty($website_id)) return;
    echo '<script defer src="https://cloud.umami.is/script.js" data-website-id="' . esc_attr($website_id) . '"></script>';
}
add_action('wp_footer', 'evanphoto_output_umami_script', 20);

// ─────────────────────────────────────────
// REST API — mobile add photo
// ─────────────────────────────────────────

function evanphoto_register_rest_routes() {
    register_rest_route('evanphoto/v1', '/photo', [
        'methods'             => 'POST',
        // Require login AND upload capability
        'permission_callback' => function() {
            return is_user_logged_in() && current_user_can('upload_files');
        },
        'callback' => 'evanphoto_rest_create_photo',
    ]);
}
add_action('rest_api_init', 'evanphoto_register_rest_routes');

/**
 * Process uploaded image:
 * 1. Apply EXIF orientation so the image is visually upright.
 * 2. Save as WebP.
 * 3. Store correct width/height and EXIF meta.
 *
 * NOTE: We no longer force a fixed 1280×853 crop.
 * Instead we scale the longest edge to ≤1280px, preserving aspect ratio.
 * This keeps portrait images tall rather than squashing them to landscape.
 */
function evanphoto_process_attachment_webp(int $attachment_id) {
    $file = get_attached_file($attachment_id);
    if (!$file || !file_exists($file)) {
        return new WP_Error('evanphoto_no_file', 'Uploaded file not found');
    }

    if (!function_exists('imagecreatefromstring') || !function_exists('imagewebp')) {
        return new WP_Error('evanphoto_gd_missing', 'Server GD/WebP support is required');
    }

    $bytes = @file_get_contents($file);
    if ($bytes === false) return new WP_Error('evanphoto_read_fail', 'Failed to read uploaded file');

    $src = @imagecreatefromstring($bytes);
    if (!$src) return new WP_Error('evanphoto_decode_fail', 'Unsupported image format');

    // ── Apply EXIF orientation ──
    // Must read orientation BEFORE the file may be overwritten
    $rotation = evanphoto_exif_orientation_angle($file);
    if ($rotation !== 0) {
        $rotated = @imagerotate($src, $rotation, 0);
        if ($rotated) {
            imagedestroy($src);
            $src = $rotated;
        }
    }

    $src_w = imagesx($src);
    $src_h = imagesy($src);
    if ($src_w <= 0 || $src_h <= 0) {
        imagedestroy($src);
        return new WP_Error('evanphoto_bad_size', 'Invalid image size');
    }

    // ── Scale to max 1280px on longest edge, preserve aspect ratio ──
    $max_dim = 1280;
    if ($src_w > $max_dim || $src_h > $max_dim) {
        $ratio  = min($max_dim / $src_w, $max_dim / $src_h);
        $dst_w  = (int) round($src_w * $ratio);
        $dst_h  = (int) round($src_h * $ratio);
    } else {
        $dst_w = $src_w;
        $dst_h = $src_h;
    }

    $dst = imagecreatetruecolor($dst_w, $dst_h);
    imagealphablending($dst, false);
    imagesavealpha($dst, true);
    $transparent = imagecolorallocatealpha($dst, 0, 0, 0, 127);
    imagefilledrectangle($dst, 0, 0, $dst_w, $dst_h, $transparent);

    $ok = imagecopyresampled($dst, $src, 0, 0, 0, 0, $dst_w, $dst_h, $src_w, $src_h);
    imagedestroy($src);
    if (!$ok) {
        imagedestroy($dst);
        return new WP_Error('evanphoto_resample_fail', 'Failed to process image');
    }

    // ── Save as WebP ──
    $dir      = dirname($file);
    $base     = pathinfo($file, PATHINFO_FILENAME);
    $filename = $base . '-evanphoto.webp';
    if (function_exists('wp_unique_filename')) {
        $filename = wp_unique_filename($dir, $filename);
    }
    $dest_path = $dir . DIRECTORY_SEPARATOR . $filename;

    $saved = imagewebp($dst, $dest_path, 82);
    imagedestroy($dst);

    if (!$saved || !file_exists($dest_path)) {
        return new WP_Error('evanphoto_webp_fail', 'Failed to save WebP');
    }

    $old_file = $file;
    update_attached_file($attachment_id, $dest_path);
    wp_update_post(['ID' => $attachment_id, 'post_mime_type' => 'image/webp']);

    if (!function_exists('wp_generate_attachment_metadata')) {
        require_once ABSPATH . 'wp-admin/includes/image.php';
    }
    $meta = wp_generate_attachment_metadata($attachment_id, $dest_path);
    if (is_wp_error($meta)) return $meta;
    wp_update_attachment_metadata($attachment_id, $meta);

    if ($old_file && file_exists($old_file) && $old_file !== $dest_path) {
        @unlink($old_file);
    }

    return ['width' => $dst_w, 'height' => $dst_h];
}

function evanphoto_rest_create_photo(WP_REST_Request $req) {
    $source = $req->get_param('source');
    if (!in_array($source, ['attachment','external'], true)) {
        return new WP_REST_Response(['ok'=>false,'message'=>'Invalid source'], 400);
    }

    $title = $req->get_param('title');
    $title = is_string($title) ? sanitize_text_field($title) : '';
    if ($title === '') $title = 'Photo';

    $post_id = wp_insert_post([
        'post_type'   => EVANPHOTO_CPT,
        'post_status' => 'publish',
        'post_title'  => $title,
    ], true);

    if (is_wp_error($post_id)) {
        return new WP_REST_Response(['ok'=>false,'message'=>$post_id->get_error_message()], 500);
    }

    update_post_meta($post_id, EVANPHOTO_META_IS_IMPORTED, 0);
    update_post_meta($post_id, EVANPHOTO_META_MARKED,      0);

    if ($source === 'external') {
        $url = $req->get_param('external_url');
        $url = is_string($url) ? esc_url_raw($url) : '';
        if (!$url) {
            wp_delete_post($post_id, true);
            return new WP_REST_Response(['ok'=>false,'message'=>'Missing URL'], 400);
        }
        update_post_meta($post_id, EVANPHOTO_META_SOURCE,       'external');
        update_post_meta($post_id, EVANPHOTO_META_EXTERNAL_URL, $url);
        delete_post_meta($post_id, EVANPHOTO_META_ATTACHMENT_ID);
        evanphoto_cache_external_dimensions($post_id, $url);

        return new WP_REST_Response(['ok'=>true,'post_id'=>$post_id], 200);
    }

    // ── File upload path ──
    if (!function_exists('media_handle_upload')) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
    }

    if (empty($_FILES) || !isset($_FILES['file'])) {
        wp_delete_post($post_id, true);
        return new WP_REST_Response(['ok'=>false,'message'=>'Missing file'], 400);
    }

    // Extract EXIF before WordPress moves the file
    $tmp_path = $_FILES['file']['tmp_name'] ?? '';
    $exif_data = $tmp_path ? evanphoto_extract_exif($tmp_path) : [];

    $attachment_id = media_handle_upload('file', $post_id);
    if (is_wp_error($attachment_id)) {
        wp_delete_post($post_id, true);
        return new WP_REST_Response(['ok'=>false,'message'=>$attachment_id->get_error_message()], 500);
    }

    // Process: orient + scale + convert to WebP
    $conv = evanphoto_process_attachment_webp(intval($attachment_id));
    if (is_wp_error($conv)) {
        wp_delete_post($post_id, true);
        return new WP_REST_Response(['ok'=>false,'message'=>$conv->get_error_message()], 500);
    }

    update_post_meta($post_id, EVANPHOTO_META_SOURCE,        'attachment');
    update_post_meta($post_id, EVANPHOTO_META_ATTACHMENT_ID, intval($attachment_id));
    delete_post_meta($post_id, EVANPHOTO_META_EXTERNAL_URL);

    // Store final dimensions and EXIF on the photo post
    if (is_array($conv)) {
        update_post_meta($post_id, EVANPHOTO_META_WIDTH,  $conv['width']);
        update_post_meta($post_id, EVANPHOTO_META_HEIGHT, $conv['height']);
    }
    if (!empty($exif_data)) {
        update_post_meta($post_id, EVANPHOTO_META_EXIF_JSON, wp_json_encode($exif_data, JSON_UNESCAPED_UNICODE));
    }

    return new WP_REST_Response(['ok'=>true,'post_id'=>$post_id,'attachment_id'=>$attachment_id], 200);
}

// ─────────────────────────────────────────
// Pretty URL: /p/{id}
// ─────────────────────────────────────────

function evanphoto_add_rewrite_rules() {
    add_rewrite_rule('^p/([0-9]+)/?$', 'index.php?photo=$matches[1]', 'top');
}
add_action('init', 'evanphoto_add_rewrite_rules');

function evanphoto_query_vars($vars) {
    $vars[] = 'photo';
    return $vars;
}
add_filter('query_vars', 'evanphoto_query_vars');

function evanphoto_template_redirect() {
    $photo = get_query_var('photo');
    if ($photo === '') return;

    status_header(200);
    add_filter('pre_get_document_title', function(){ return 'Photos'; });
    include get_template_directory() . '/front-page.php';
    exit;
}
add_action('template_redirect', 'evanphoto_template_redirect');

function evanphoto_after_switch_theme() {
    evanphoto_add_rewrite_rules();
    flush_rewrite_rules();
}
add_action('after_switch_theme', 'evanphoto_after_switch_theme');

// ─────────────────────────────────────────
// Mobile: hide admin bar on frontend
// ─────────────────────────────────────────

function evanphoto_hide_admin_bar_on_mobile($show) {
    if (is_admin()) return $show;
    if (function_exists('wp_is_mobile') && wp_is_mobile()) return false;
    return $show;
}
add_filter('show_admin_bar', 'evanphoto_hide_admin_bar_on_mobile');
