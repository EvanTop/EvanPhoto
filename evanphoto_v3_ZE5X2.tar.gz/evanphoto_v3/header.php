<?php if (!defined('ABSPATH')) { exit; }
?><!doctype html>
<html <?php language_attributes(); ?> class="h-full">
<head>
  <meta charset="<?php bloginfo('charset'); ?>" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <?php wp_head(); ?>
</head>
<body <?php body_class('h-full bg-black'); ?>>
<?php wp_body_open(); ?>
